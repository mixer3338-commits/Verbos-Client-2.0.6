# Source and third-party licenses

This source package is based on the public Veltragossa Client source repository:
<https://github.com/Mevinggs/Veltragossa-client>

The upstream repository provides its code under GNU GPL version 3. This package
is a modified version dated 2026-10-25, including changes to the GUI and HUD.
The corresponding source for this release is distributed alongside the mod.
Keep this notice and the upstream copyright and license notices when
redistributing.

## Bundled components

| Component | Version | License | Upstream |
| --- | --- | --- | --- |
| Veltragossa-derived client source | upstream source | GPL-3.0-only | <https://github.com/Mevinggs/Veltragossa-client> |
| Orbit | 0.2.3 | MIT | <https://github.com/MeteorDevelopment/orbit> |
| MediaPlayerInfo | 0.1.0 | AGPL-3.0-only | <https://github.com/Redstonecrafter0/MediaPlayerInfo> |

Complete license texts are included in `LICENSES/`, under
`src/main/resources/META-INF/licenses/`, and in the built mod JAR. Follow the
applicable license for each component; the license identifiers in Fabric
metadata list the licenses needed to redistribute the package.

The matching source JARs for the bundled dependencies are included under
`THIRD-PARTY-SOURCES/` in the source archive.

Minecraft and Mojang assets are not licensed by these notices. This package
does not claim endorsement by Veltragossa, Mojang, or Microsoft.
