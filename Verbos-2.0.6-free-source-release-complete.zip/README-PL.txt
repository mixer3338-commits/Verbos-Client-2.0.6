Verbos Client 2.0.6 — darmowa paczka źródłowa

Zawartość:
- Verbos-2.0.6.jar — Fabric mod JAR.
- Verbos-2.0.6-source.zip — odpowiadające źródła, źródła dołączonych bibliotek,
  konfiguracja budowania i informacje licencyjne.
- LICENSES.md oraz LICENSES/ — zestawienie i pełne teksty licencji komponentów.

Pochodzenie i licencje:
- Kod bazowy oparty na publicznym repozytorium Veltragossa Client (GPLv3),
  zmodyfikowana wersja z 25.10.2026.
- Orbit 0.2.3 (MIT) i MediaPlayerInfo 0.1.0 (AGPLv3); źródła i szczegóły są
  w archiwum źródeł oraz w LICENSES.md.
- Udostępniaj JAR razem z kodem źródłowym i zachowuj dołączone informacje
  licencyjne.

Ta paczka zawiera tylko moda Fabric i jego źródła. Nie zawiera plików gry
Minecraft ani osobnego injectora EXE. Nie jest wydaniem oficjalnym ani
zatwierdzonym przez Mojang/Microsoft. EULA Minecrafta i regulaminy serwerów
obowiązują niezależnie od licencji kodu; sprawdź je przed publikacją.